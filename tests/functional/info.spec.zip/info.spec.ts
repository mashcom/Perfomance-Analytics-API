import { test } from "@japa/runner";


test("get all info test", async ({ client }) => {
  const response = await client.get("/api/v1/info").send();
  response.assertStatus(200);
});

test("add new info test", async ({ client }) => {
  const data = {
    name: "Attacking",
  };
  const response = await client.post("/api/v1/info").json(data);
  response.assertStatus(200);
});
