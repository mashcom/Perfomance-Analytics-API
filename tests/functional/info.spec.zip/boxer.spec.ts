import { test } from "@japa/runner";


test("get all boxers test", async ({ client }) => {
  const response = await client.get("/api/v1/boxer").send()
  response.assertStatus(200);
});

test("add new boxer test", async ({ client }) => {
  const data = {
    name: "Blessing Mashoko",
    description: "From Zimbabwe",
    dob: "11/07/1993",
    weight: 80,
    height: 171,
    reach: 2
  };
  const response = await client.post("/api/v1/boxer").json(data);
  response.assertStatus(200);
  response.assertTextIncludes(data.name)
});
