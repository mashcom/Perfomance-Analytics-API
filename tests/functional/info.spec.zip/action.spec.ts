import { test } from "@japa/runner";


test("get all action test", async ({ client }) => {
  const response = await client.get("/api/v1/action").send();
  response.assertStatus(200);
});

test("add new action test", async ({ client }) => {
  const data = {
    info_id: 1,
    name: "Punch"
  };
  const response = await client.post("/api/v1/action").json(data);
  response.assertStatus(200);
});
