import { test } from "@japa/runner";


test("get all fights test", async ({ client }) => {
  const response = await client.get("/api/v1/fight").send();
  response.assertStatus(200);
});

test("add new fight test", async ({ client }) => {
  const data = {
    rounds: 5,
    boxer1: 1,
    boxer2: 2
  };
  const response = await client.post("/api/v1/fight").json(data);
  response.assertStatus(200);
});
