import { test } from "@japa/runner";


test("get all outcome test", async ({ client }) => {
  const response = await client.get("/api/v1/outcome").send();
  response.assertStatus(200);
});

test("add new target test", async ({ client }) => {
  const data = {
    action_id: 1,
    outcome: "success",
    boxer_id: 1,
    fight_id: 1
  };
  const response = await client.post("/api/v1/outcome").json(data);
  response.assertStatus(200);
});
