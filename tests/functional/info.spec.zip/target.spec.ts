import { test } from "@japa/runner";


test("get all target test", async ({ client }) => {
  const response = await client.get("/api/v1/target").send();
  response.assertStatus(200);
});

test("add new target test", async ({ client }) => {
  const data = {
    name: "Body"
  };
  const response = await client.post("/api/v1/target").json(data);
  response.assertStatus(200);
});
